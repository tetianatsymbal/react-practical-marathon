import React, { createContext} from "react";
import './App.css';
import Contacts from './contacts';
import Logo from "./Logo";

export const ContactContext = React.createContext();


function App() {

// NOTE: Use context provider in this component 
  const Context = createContext();
  const [contacts, setContacts] = useState([
    { channelOption: '', details: '' }
  ]);
  const addContacts = () => {
    setContacts([...contacts, { channelOption: '', details: '' }]);
  }
   const updateContact = (index, key, value) => {
    const newContacts = [...contacts];
    newContacts[index][key] = value;
    setContacts(newContacts);
  };
  const deleteContact = (index) => {
    const newContacts = [...contacts];
    newContacts.splice(index, 1);
    setContacts(newContacts);
  };
  const value = {
    index,
    contacts,
    setContacts,
    addContacts,
    updateContact,
    deleteContact,
    channelOption,
    details,
  };
  return (
    <Context.Provider value={value}>
      <div className="grid-container">
        <div>
          <Contacts/>
        </div>
        <div>       
          <Logo />
        </div>
      </div>
    </Context.Provider>
  );
}

export default App;
