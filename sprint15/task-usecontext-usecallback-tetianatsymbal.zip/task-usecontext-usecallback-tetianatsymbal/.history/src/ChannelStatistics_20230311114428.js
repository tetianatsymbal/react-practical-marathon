import React, { useContext } from 'react'
import { ContactContext } from './App';

function ChannelStatistics() {

  // NOTE: use Context to get info about entered contacts
  const {contacts} = useContext(ContactContext);
  console.log(contacts[contacts.length - 1].channelOption);
  return (
    <p  data-testid="statistics">
      count of channels: {contacts.length}<br />
      {(contacts[contacts.length - 1].channelOption)
        ? `your last channel is: {contacts[contacts.length - 1].channelOption}`
        : ""
      }
      
    </p>
  )
}

export default ChannelStatistics