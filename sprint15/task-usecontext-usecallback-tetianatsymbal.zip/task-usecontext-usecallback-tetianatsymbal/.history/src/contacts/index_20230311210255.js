import React, { useContext } from "react";
import stylesCenter from "./index.module.css";
import ContactItem from "./ContactItem";
import { ContactContext } from "../App";


const Contacts = () => {
  // NOTE: 'teach' the button to add new contact info
  // NOTE: and render an array of ContactItem components
  
  const {contacts, addContacts,  channel, updateChannel} = useContext(ContactContext);

  return (
    <>
      <div className={stylesCenter.channels}>    
        {contacts.map((contact, index) => (
          <ContactItem
            key={index}
            index={index}
            channel={contact.channel}
            contact={contact}
            // updateContact={updateContact}
            updateChannel={updateChannel}
            // deleteContact ={deleteContact}
          />
        ))}
      </div>
      <div>
        <button
          className={stylesCenter.addButton}
          data-testid="add-button"
          onClick={addContacts}
        >
          <img src="plus.svg" alt="plus logo" />
          <span className={stylesCenter.addButtonText}>
            Додати канал зв'язку
          </span>
        </button>
      </div>
    </>
  );
};

export default Contacts;