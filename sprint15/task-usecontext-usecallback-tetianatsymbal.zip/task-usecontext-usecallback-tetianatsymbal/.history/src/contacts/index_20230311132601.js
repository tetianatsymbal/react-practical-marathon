import React, { useContext } from "react";
import stylesCenter from "./index.module.css";
import ContactItem from "./ContactItem";
import { ContactContext } from "../App";


const Contacts = () => {
  // NOTE: 'teach' the button to add new contact info
  // NOTE: and render an array of ContactItem components
  
  const value = useContext(ContactContext);

  return (
    <>
      <div className={stylesCenter.channels}>    
        {value.contacts.map((contact, index) => (
          <ContactItem
   
            index={index}
            contact={contact}
            // channelOption={contact.channelOption}
            // details={contact.details}
            // onUpdate={updateContact}
            // onDelete={deleteContact}
          />
        ))}
      </div>
      <div>
        <button
          className={stylesCenter.addButton}
          data-testid="add-button"
          onClick={value.addContacts}
        >
          <img src="plus.svg" alt="plus logo" />
          <span className={stylesCenter.addButtonText}>
            Додати канал зв'язку
          </span>
        </button>
      </div>
    </>
  );
};

export default Contacts;