import React from "react";
import stylesCenter from "./index.module.css";
import ContactItem from "./ContactItem";


const Contacts = () => {
  // NOTE: 'teach' the button to add new contact info
  // NOTE: and render an array of ContactItem components
  const [contacts, setContacts] = useState([]);
  const addContacts = () => {
    setContacts([...contacts, { channelOption: '', details: '' }]);
  }
  const deleteContact = (index) => {
    const newContacts = [...contacts];
    newContacts.splice(index, 1);
    setContacts(newContacts);
  };
  
  return (
    <>
      <div className={stylesCenter.channels}>    
        {contacts.map((contact, index) => (
          <ContactItem
            key={index}
            index={index}
            channelOption={contact.channelOption}
            details={contact.de}
            onDelete={deleteContact}
          />
        ))}
      </div>
      <div>
        <button
          className={stylesCenter.addButton}
          data-testid="add-button"
          onClick={addContacts}
        >
          <img src="plus.svg" alt="plus logo" />
          <span className={stylesCenter.addButtonText}>
            Додати канал зв'язку
          </span>
        </button>
      </div>
    </>
  );
};

export default Contacts;