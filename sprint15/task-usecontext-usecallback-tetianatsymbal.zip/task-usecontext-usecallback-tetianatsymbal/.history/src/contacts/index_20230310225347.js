import React, { useState } from "react";
import stylesCenter from "./index.module.css";
import ContactItem from "./ContactItem";


const Contacts = () => {
  // NOTE: 'teach' the button to add new contact info
  // NOTE: and render an array of ContactItem components
  const [contacts, setContacts] = useState([]);
  const addContacts = () => {
    setContacts([...contacts, { channelOption: '', details: '' }]);
  }
   const updateChannel = (index, key, value) => {
    const newContacts = [...contacts];
    newContacts[index][key] = value;
    setContacts(newContacts);
  };
  const deleteContact = (index) => {
    const newContacts = [...contacts];
    newContacts.splice(index, 1);
    setContacts(newContacts);
  };
  
  return (
    <>
      <div className={stylesCenter.channels}>
        <ContactItem
            key={index}
            index={0}
            channelOption={contact.channelOption}
            details={contact.details}
            onUpdate={updateChannel}
            onDelete={deleteContact}
          />
        {contacts.map((contact, index) => (
          <ContactItem
            key={index}
            index={0}
            channelOption={contact.channelOption}
            details={contact.details}
            onUpdate={updateChannel}
            onDelete={deleteContact}
          />
        ))}
      </div>
      <div>
        <button
          className={stylesCenter.addButton}
          data-testid="add-button"
          onClick={addContacts}
        >
          <img src="plus.svg" alt="plus logo" />
          <span className={stylesCenter.addButtonText}>
            Додати канал зв'язку
          </span>
        </button>
      </div>
    </>
  );
};

export default Contacts;