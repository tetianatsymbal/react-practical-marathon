import React, { useContext } from "react";
import stylesCenter from "./index.module.css";
import ContactItem from "./ContactItem";
import { ContactContext } from "../App";


const Contacts = () => {
  // NOTE: 'teach' the button to add new contact info
  // NOTE: and render an array of ContactItem components
  
  const {contacts, addContacts, updateContact, deleteContact} = useContext(ContactContext);

  const handleChanelChange = useCallback((e) => {
    updateContact(index, "channelOption", e.target.value);
  }, [index, updateContact])

  const handleDetailsChange = useCallback((e) => {
    updateContact(index, "details", e.target.value);
  }, [index, updateContact])

  const handleDeleteClick = useCallback(() => {
    deleteContact(index);
  }, [index, deleteContact])

  return (
    <>
      <div className={stylesCenter.channels}>    
        {contacts.map((contact, index) => (
          <ContactItem
            key={contact.index}
            index={index}
            contact={contact}
            updateContact={updateContact}
            deleteContact={deleteContact}
            handleChanelChange={handleChanelChange}
            handleDetailsChange={handleDetailsChange}
            handleDeleteClick={handleDeleteClick}
          />
        ))}
      </div>
      <div>
        <button
          className={stylesCenter.addButton}
          data-testid="add-button"
          onClick={addContacts}
        >
          <img src="plus.svg" alt="plus logo" />
          <span className={stylesCenter.addButtonText}>
            Додати канал зв'язку
          </span>
        </button>
      </div>
    </>
  );
};

export default Contacts;