import React, { createContext} from "react";
import './App.css';
import Contacts from './contacts';
import Logo from "./Logo";

export const ContactContext = React.createContext();


function App() {

// NOTE: Use context provider in this component 
  const Context = createContext();

  return (
    <UserContext.Provider value={user}>
      <div className="grid-container">
        <div>
          <Contacts/>
        </div>
        <div>       
          <Logo />
          
        </div>
        </div>
      </UserContext.Provider>
  );
}

export default App;
