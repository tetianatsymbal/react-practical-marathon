import React from 'react'

function ChannelStatistics() {

  // NOTE: use Context to get info about entered contacts

  return (
    <p  data-testid="statistics">
      count of channels: <br />
      'your last channel is: '
    </p>
  )
}

export default ChannelStatistics