import React, {useCallback, useState} from "react";
import './App.css';
import Contacts from './contacts';
import Logo from "./Logo";

export const ContactContext = React.createContext();

function App() {
// NOTE: Use context provider in this component 
  const [contacts, setContacts] = useState([
    { channelOption: '', details: '' }
  ]);
  const [channel, setChannel] = useState('');
  const addContacts = useCallback(() => {
    // let lastIndex = contacts[contacts.length - 1].index;
    setContacts([...contacts, { channelOption: channel, details: '' }]);
  }, [contacts]);

  const updateContact = useCallback((index, key, value) => {
    const newContacts = [...contacts];
    newContacts[index][key] = value;
    setContacts(newContacts);
  }, [contacts]);

  // const deleteContact = useCallback((index) => {
  //   const newContacts = contacts.filter((el, i) => i !== index);
  //   setContacts(newContacts);
  // }, [contacts]);

  const value = {
    contacts,
    setContacts,
    addContacts,
    updateContact,
    // deleteContact
  };
  return (
    <ContactContext.Provider value={value}>
      <div className="grid-container">
        <div>
          <Contacts/>
        </div>
        <div>       
          <Logo />
        </div>
      </div>
    </ContactContext.Provider>
  );
}

export default App;
