import React, { useContext } from 'react'

function ChannelStatistics() {

  // NOTE: use Context to get info about entered contacts
  const {contacts} = useContext(ContactContext);

  return (
    <p  data-testid="statistics">
      count of channels: {contacts.length - 1}<br />
      {contacts[contacts.length - 1].channelOption 
        ? `your last channel is:${contacts[contacts.length - 1].channelOption}`
        : ""
      }
      
    </p>
  )
}

export default ChannelStatistics