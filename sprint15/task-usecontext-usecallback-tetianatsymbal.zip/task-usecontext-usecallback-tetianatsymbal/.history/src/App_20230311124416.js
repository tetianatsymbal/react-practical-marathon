import React, {useState} from "react";
import './App.css';
import Contacts from './contacts';
import Logo from "./Logo";

export const ContactContext = React.createContext();

function App() {

// NOTE: Use context provider in this component 
  const [contacts, setContacts] = useState([
    { channelOption: '', details: '' }
  ]);

  const addContacts = () => {
    setContacts([...contacts, { channelOption, details }]);
  }
  const updateContact = (index, key, value) => {
    const newContacts = [...contacts];
    newContacts[index][key] = value;
    setContacts(newContacts);
  };

  const deleteContact = (index) => {
    const newContacts = contacts.filter((el, i) => i !== index);
    setContacts(newContacts);
  };

  const value = {
    contacts,
    setContacts,
    addContacts,
    updateContact,
    deleteContact
  };
  return (
    <ContactContext.Provider value={value}>
      <div className="grid-container">
        <div>
          <Contacts/>
        </div>
        <div>       
          <Logo />
        </div>
      </div>
    </ContactContext.Provider>
  );
}

export default App;
