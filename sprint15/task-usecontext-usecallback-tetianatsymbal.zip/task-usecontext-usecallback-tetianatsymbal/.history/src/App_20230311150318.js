import React, {useCallback, useMemo, useState} from "react";
import './App.css';
import Contacts from './contacts';
import Logo from "./Logo";

export const ContactContext = React.createContext();

function App() {

// NOTE: Use context provider in this component 
  const [contacts, setContacts] = useState([
    { index: 0, channelOption: '', details: '' }
  ]);

  const updateContact = useCallback((index, key, value) => {
    const newContacts = [...contacts];
    newContacts[index][key] = value;
    setContacts(newContacts);
  }, []);

  const deleteContact = useCallback((index) => {
    const newContacts = contacts.filter((el, i) => i !== index);
    setContacts(newContacts);
  }, []);

  //const updateOption = useMemo(() => updateContact(index, key, value), [index, key, value]);
  //const deleteOption = useMemo(() => deleteContact(index), [index])

const addContacts = () => {
    let lastIndex = contacts[contacts.length-1].index;
    setContacts([...contacts, { index: lastIndex+1, channelOption: '', details: '' }]);
  }

  const value = {
    contacts,
    setContacts,
    addContacts,
    updateContact,
    deleteContact
  };
  return (
    <ContactContext.Provider value={value}>
      <div className="grid-container">
        <div>
          <Contacts/>
        </div>
        <div>       
          <Logo />
        </div>
      </div>
    </ContactContext.Provider>
  );
}

export default App;
